#!flask/bin/python
# Part 7

from app import app
app.run(debug=False)
