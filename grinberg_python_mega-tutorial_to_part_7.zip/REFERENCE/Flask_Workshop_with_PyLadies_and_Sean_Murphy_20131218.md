## Flask Workshop with PyLadies 20131218

http://www.meetup.com/flask-nyc/events/154634982/

Instructor: Sean Patrick Murphy (Johns Hopkins)

We are following http://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-i-hello-world

### Completed:

  * Part 1, no problems


### Jinja2 syntax

  * `{{...}}` for templates
  * `{%...%}` for control statements
  * `a.b` and `a.b.c` for nested dictionary keys



### Comments

Flask is preferable for learning because a single-file web server can be constructed in merely 10 lines.

